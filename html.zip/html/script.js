4 + 3;
if (4 + 3===7) {
    alert("You are smart!");
}
console.log("heloooooooo", "how are you");

function sayHello() {
    console.log("hello");
}
sayHello();
var sayBye = function() {
    console.log("Bye");
}
sayBye();

function sing() {
    console.log("Medicine and Surgery");
    console.log("Bachelor of Dental Surgery");
}
sing();

function sing (song) {
    console.log(song);
}
sing("brachial plexus");
sing("Axilla");
sing("Cubital fossa")

Array
var list=["tiger", "cat", "birds", "cow"];
console.log(list[1]);

Object
var user = {
    name: "ogbadu",
    Age: "27",
    hobby: "soccer",
    ismarried: "false",
    shout:function(){
        console.log("aaaaaaaaaah");
    }
};
var list= ["apple", "banana", "orange", ""]

null

var database = [
    {
        username: "Ogbadu friday",
        password: "highlysecret",
    }
];

var database = [
    {
        username: "ogbadu Johnson",
        Timeline: "all thanks to God"
    },
    {
        username: "ogbadu maneju",
        Timeline: "Javascript is beautiful"
    }
];
var userNameprompt = prompt("what is your username?");
var passwordprompt = prompt("whta is your password?");

function signIn(user, pass) {
    if (user=== database[0].username &&
    pass=== database[1].password) {
        console.log("newsFeeds");
    } else {
        alert("sorry, wrong username and password");
    }
}
signIn(userNameprompt, passwordprompt); 



const todolist = ["ball", "sleep", "eat"];
for (let i=0; i< 3; i++) 
    console.log(todolist[i])
    
    function isuservalid(bool) {
        return bool;
    }
    var answer =isuservalid(true)? "you may enter":"access denied";

    function movecommand(direction){
        var whathappens;
        switch(direction) {
            case "forward":
                whathappens= "you encounter a monster";
                break;
                   case "back":
                whathappens= "you arrive";
                break;
            case "right":
                    whathappens= "you found a river";
                    break;
            case "left":
                        whathappens= "you run into a troll";
                        break;
            default:
                whathappens= "enter a valid direction"
                    
        }
        return whathappens;
    }