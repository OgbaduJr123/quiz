var todolist = [
    "Clean room",
    "Brush teeth",
    "Exercise",
    "Study javascript",
    "Eat Healthy"
];
for (var i=0; i < todolist.length; i++) {
    console.log(todolist[i]+"!");
}

var counterOne=0;
while (counterOne < 10) {
    console.log(counterOne);
    counterOne++
}

var counterOne=10;
while (counterOne > 0) {
    console.log(counterOne);
    counterOne--
}

var counterTwo=10
do {
    console.log(counterTwo);
    counterTwo--;
} while (counterTwo > 0);

todolist.forEach(function (todolist, i) {
    console.log(todolist, i)
})