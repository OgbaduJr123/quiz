var button = document.getElementsByTagName("button")[0];

button.addEventListener("click", funtion() {
    console.log("CLICK!!!!");
})

var button = document.getElementById("enter");
var input = document.getElementById("userid");

button.addEventListener("click", funtion() {
    console.log("click is working");
})

const array = [1, 2, 10, 16];

const double =[]
const newArray = array.forEach((num) => {
    double.push(num * 2);
});

console.log('forEach', double);

//map filter, reduce

const maparray = array.map((num)=>{
    return num *2;
});
console.log('map', maparray);

// filter
const filterArray = array.filter (num => num >5);

console.log('filter', filterArray);


//reduce
const reducearray = array.reduce((accumulator, num) =>{
    return accumulator + num
}, 0);
console.log('reduce', reducearray);

const fun = (a, b, c, d,) => {
    console.log(a);
}
fun(1,2,3,4,)

Object.values
Object.entries
Object.keys
 
let obj = {
    username0: 'ogbadu',
    username1: 'omede',
    username2: 'meneju'
}

Object.keys(obj).forEach ((key, index) => {
    console.log (key, obj[key]);
})

Object.values(obj).forEach(value => {
    console.log(value);
})

Object.entries(obj).forEach(value => {
    console.log(value);
})

Object.entries(obj).map(value => {
    return value[1] + value[0].replace ('username', '');
})

ADVANCE LOOP

const basket = ['Apples', 'oranges', 'grapes'];
//1
const basket = ['Apples', 'oranges', 'grapes'];
for (let i = 0; i < basket.length; i++) {
    console.log(basket[i]);
}

//2
const basket = ['Apples', 'oranges', 'grapes'];
basket.forEach(item => {
    console.log(item)
})

// for of
// iterating
const basket = ['Apples', 'oranges', 'grapes'];
for (item of basket) {
    console.log(item);
}

// for of
// iterating is for arrays, strings
const basket = ['Apples', 'oranges', 'grapes'];
for (item of 'basket') {
    console.log(item);
}


// for of- properties
// enumerating is for objects
const detailedBasket = {
    apples: 5, 
    oranges: 10,
    grapes: 1000
}

for (item in detailedBasket) {
    console.log(item)
}

debugging
const flattened = [[0, 1], [2, 3], [4, 5]]. reduce(
     (accumulator, array) => {
        console.log('array', array);
        console.log('accumulator', accumulator);
      return accumulator.concat(array)}, []);


      asynchronous programming
      console.log('1');
      setTimeout(()=> {
        console.log('2');
      }, 2000)
      console.log('3');




































































































































































8'