var todolist = [
    "wash",
    "Read",
    "Movies",
    "code",
];
for (var i=0; i < todolist.length; i++) {
    console.log(todolist[i]+"!");
}